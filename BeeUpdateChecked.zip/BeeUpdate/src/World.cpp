#include "World.h"
#include <GL/glut.h>
#include <math.h>
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include<ctime>
#include "time.h"
#include "BeePlayer.h"
#include "RivalBee.h"
#include "WindMill.h"
#include <vector>
#include "Flower.h"
//#include "Sprinkler.h"
#include "Tree.h"
#include "Person.h"

using namespace std;
World::World()
 {

         distance=0;
         bee=new BeePlayer(-8.0f, 2.0f, -10.0f,1.58f,1.98f);
         rB=new RivalBee(-12.0f,2.0f,-55.0f,0.5f,3.0f,3.0f,0.7f);
         person=new Person(-8.0f,0.0f,-18.0f,0.65f);
         windmill=new WindMill(12.0f,0.0f,19.0f,3.5f,0.0f,2.5f);
         tree=new Tree(0.15f,1.0f,-8.0f,-4.0f,3.0f);
         flower=new Flower(-12.0f,0.0f,-19.0f,0.1f);
 }


void World::render(){
    glPushMatrix();
      bee->render();
    glPopMatrix();

//    sprinkler.DrawFountain();
    glPushMatrix();
        person->render();
    glPopMatrix();
    glPushMatrix();
        rB->render();
    glPopMatrix();
    glPushMatrix();
        tree->render();
    glPopMatrix();
    glPushMatrix();
        windmill->render();
    glPopMatrix();

    glPushMatrix();
        flower->render();
    glPopMatrix();
}


bool World::detectCollision2(){
    //r1= bee->radius+windmill->radius;
    r2= bee->radius+person->radius;
    //r3= bee->radius+rB->radius;
    bool isColliding=false;
    float dist=pow((bee->x-person->x),2)+pow((bee->z-person->z),2);//+pow((bee->y-person->y),2)z
    dist = sqrt(dist);

    if(dist<=r2){
        isColliding=true;
    }
    else{
        isColliding=false;
    }

    //
    cout<<"is colliding "<< isColliding<<endl;
    cout<<"dist = "<< dist <<endl;
    cout<<"r2   = "<< r2<<endl;
    return isColliding;
}
bool World::detectCollision1(){
    r1= bee->radius+windmill->radius;
    //r2= bee->radius+person->radius;
    //r3= bee->radius+rB->radius;
    bool isColliding=false;
    float dist=pow((bee->x-windmill->x),2)+pow((bee->y-windmill->y),2)+pow((bee->z-windmill->z),2);
    dist = sqrt(dist);

    if(dist<=r1){
        isColliding=true;
    }
    else{
        isColliding=false;
    }

    //
    cout<<"is colliding "<< isColliding<<endl;
    cout<<"dist = "<< dist <<endl;
    cout<<"r1   = "<< r1<<endl;
    return isColliding;
}
bool World::detectCollision3(){

    r3= bee->radius+rB->radius;
    bool isColliding=false;
    float dist=pow((bee->x-rB->x),2)+pow((bee->y-rB->y),2)+pow((bee->z-rB->z),2);
    dist = sqrt(dist);

    if(dist<=r3){
        isColliding=true;
    }
    else{
        isColliding=false;
    }

    //
    cout<<"is colliding "<< isColliding<<endl;
    cout<<"dist = "<< dist <<endl;
    cout<<"r3   = "<< r3<<endl;
    return isColliding;
}
void World::moveBeeLeft(){

 if(!detectCollision2()){
    bee->moveBeeLeft();
 }
// else if(!detectCollision2()){
//    bee->moveBeeLeft();
// }
//  else if(!detectCollision3()){
//    bee->moveBeeLeft();
// }
else{
    bee->z=-10.0;
 }
 }
void World::moveBeeRight(){

     if(!detectCollision2()){
    bee->moveBeeRight();
 }
// else if(!detectCollision2()){
//    bee->moveBeeRight();
// }
//  else if(!detectCollision3()){
//    bee->moveBeeRight();
// }
else{
    bee->z=-10.0;
 }
}

void World::moveBeeUp(){

bee->moveBeeUp();
}
void World::moveBeeDown(){

if(bee->y>=-0.3){
bee->moveBeeDown();
}

}
void World::moveBeeForward(){
if(bee->z<=45){
  if(!detectCollision2()){
    bee->moveBeeForward();
 }
// else if(!detectCollision2()){
//    bee->moveBeeForward();
// }
//  else if(!detectCollision3()){
//    bee->moveBeeForward();
// }
else{
     bee->z=-10.0;
 }
 }
}
void World::moveBeeBackward(){
if(bee->z>=-45){
 if(!detectCollision2()){
   bee->moveBeeBackward();
 }
// else if(!detectCollision2()){
//    bee->moveBeeBackward();
// }
//  else if(!detectCollision3()){
//    bee->moveBeeBackward();
// }
else{
    bee->z=-10.0;
 }
}
}
