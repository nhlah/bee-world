#ifndef BEEPLAYER_H
#define BEEPLAYER_H


class BeePlayer
{
    public:
       float x,y,z,radius,angle1;
        BeePlayer();
        BeePlayer(float x,float y,float z,float angle1,float radius);

       // void update();
        void render();
        void drawBee();
        void moveBeeLeft();
        void moveBeeRight();
        void moveBeeUp();
        void moveBeeDown();
        void moveBeeForward();
        void moveBeeBackward();
    private:




};

#endif
