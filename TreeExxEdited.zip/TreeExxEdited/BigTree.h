#ifndef BIGTREE_H_
#define BIGTREE_H_

#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#include "Tree.h"

class BigTree : public Tree {
public:
	BigTree(bool drawLeaves);
	virtual ~BigTree();

	void draw(int depth);
	void drawFoliage(GLfloat s);

private:
	void drawTree(int depth, float len, float t);
	void drawCylQ(GLfloat len, GLfloat t);
	float power(float, int);

	bool _drawLeaves;
};

#endif /*ARTIFICIALTREE_H_*/
