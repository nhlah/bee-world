#ifndef SPRINKLER_H
#define SPRINKLER_H


class Sprinkler
{
    public:
        Sprinkler();
        void CreateList();
        float GetRandomFloat(float range);
        void DrawFountain();
        void Displayy();
    protected:
    private:


};

#endif // SPRINKLER_H
