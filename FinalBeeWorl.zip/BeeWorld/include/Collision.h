#ifndef COLLISION_H
#define COLLISION_H
#include "BeePlayer.h"
#include "Flower.h"
#include "WindMill.h"

class collision
{
    public:
        collision();
        collision(double distance, double distance1);
        void detectCollision();
       // double calDistance();
    protected:

    private:
        double distance;
        double distance1;

};

#endif // COLLISION_H
