void agvInit(int allowidle);
void agvSetAllowIdle(int allowidle);


 /*
  * Set which movement mode you are in.
  */
typedef enum { FLYING, POLAR } MovementType;
void agvSwitchMoveMode(int move);

 /*
  * agvViewTransform basically does the appropriate gluLookAt() for the
  * current position.  So call it in your display on the projection matrix
  */
void agvViewTransform(void);

 /*
  * agvMoving will be set by AGV according to whether it needs you to call
  * agvMove() at the end of your idle function.  You only need these if
  * you aren't allowing AGV to do its own idle.
  * (Don't change the value of agvMoving)
  */
extern int agvMoving;
void agvMove(void);

 /*
  * These are the routines AGV registers to deal with mouse and keyboard input.
  * Keyboard input only matters in flying mode, and then only to set speed.
  * Mouse input only uses left two buttons in both modes.
  * These are all registered with agvInit(), but you could register
  * something else which called these, or reregister these as needed
  */
void agvHandleButton(int button, int state, int x, int y);
void agvHandleMotion(int x, int y);
void agvHandleKeys(unsigned char key, int x, int y);

 /*
  * Just an extra routine which makes an x-y-z axes (about 10x10x10)
  * which is nice for aligning things and debugging.  Pass it an available
  * displaylist number.
  */
void agvMakeAxesList(int displaylist);








